import { Request, Response } from "express";
import { ParamsDictionary } from "express-serve-static-core";


// Require type checking of request body.
type SafeRequest = Request<ParamsDictionary, {}, Record<string, unknown>>;
type SafeResponse = Response;  // only writing, so no need to check

// Description of an individual event
// Restrictions:
// 1 <= day <= 31
// maxTickets > 0
// ticketsLeft >= 0
export type Event = {
  event: string,
  sport: string,
  description: string,
  day: number,
  venue: string,
  maxTickets: number,
  ticketsLeft: number
};

// Map from "event,sport" to Event details
const events: Map<string, Event> = new Map();

/**
 * Testing function to remove all the added events
 */
export const resetForTesting = (): void => {
  events.clear();
}

/**
 * Sort events with ones having earlier dates first
 */
const compareEvtByDate = (a: Event, b: Event): number => {
  const aTime: number = a.day;
  const bTime: number = b.day;
  return aTime - bTime;
}

// helper event for renderRanking
// compares a and b and returns negative if a has more ticket sold
// and therefore should be before b
const compareEvtBySold = (a: Event, b: Event): number => {
  const aTiksSold: number = a.maxTickets - a.ticketsLeft;
  const bTiksSold: number = b.maxTickets - b.ticketsLeft;
  return bTiksSold - aTiksSold;
};

/**
 * Returns a list of all events, sorted in chronological order by date.
 * Also returns the top 3 most sold events in an array.
 * @param _req the request
 * @param res the response
 */
export const listEvents = (_req: SafeRequest, res: SafeResponse): void => {
  const chronologicalVals = Array.from(events.values());
  chronologicalVals.sort(compareEvtByDate);

  const top3Vals = Array.from(events.values());
  top3Vals.sort(compareEvtBySold);
  res.send({events: chronologicalVals, top3: top3Vals.slice(0, 3)})
}

/**
 * returns a map of all events.
 * @param _req the request
 * @param res the response
 */
export const eventsMap = (_req: SafeRequest, res: SafeResponse): void => {
  const eventsArray = Array.from(events.entries());
  res.send({ map: eventsArray });
}

/**
 * Updates the ticketsLeft based on ticketsBought from request.
 * Sends back the number of tickets left.
 * @param req the request
 * @param res the response
 */
export const getTickets = (req: SafeRequest, res: SafeResponse): void => {
  const name = req.body.name;
  if (typeof name !== 'string') {
    res.status(400).send("missing 'name' parameter");
    return;
  }

  const ticketsBought = req.body.ticketsBought;
  if (typeof ticketsBought !== "number") {
    res.status(400).send(`'ticketsBought' is not a number: ${ticketsBought}`);
    return;
  } else if (isNaN(ticketsBought) || ticketsBought < 1 || Math.round(ticketsBought) !== ticketsBought) {
    res.status(400).send(`'ticketsBought' is not a positive integer: ${ticketsBought}`);
    return;
  }

  const sport = req.body.sport;
  if (typeof sport !== 'string') {
    res.status(400).send("missing 'sport' parameter");
    return;
  }

  const event = req.body.event;
  if (typeof event !== 'string') {
    res.status(400).send("missing 'event' parameter");
    return;
  } else if (!events.has(`${event},${sport}`)) {
    res.status(400).send(`the given event key does not exist: [${event}, ${sport}]`);
    return;
  }

  const chosenEvent = events.get(`${event},${sport}`);
  if (chosenEvent !== undefined) {
    const currTicketsLeft = chosenEvent.ticketsLeft;
    if (currTicketsLeft < ticketsBought) {
      res.status(400).send(`'ticketsBought' is greater than tickets left: ${ticketsBought} > ${currTicketsLeft}`);
      return;
    }
    const newTicketsLeft = currTicketsLeft - ticketsBought;
    const updatedEvent = {
      event: chosenEvent.event,
      sport: chosenEvent.sport,
      description: chosenEvent.description,
      day: chosenEvent.day,
      venue: chosenEvent.venue,
      maxTickets: chosenEvent.maxTickets,
      ticketsLeft: newTicketsLeft
    }
    events.set(`${event},${sport}`, updatedEvent);
    res.send({ticketsLeft: newTicketsLeft});
  } else {
    res.status(500).send("the chosen event is not of type 'Event' but is instead undefined");
    return;
  }
}

/**
 * Add the event to the list and sends back the event made.
 * @param req the request
 * @param res the response
 */
export const addEvent = (req: SafeRequest, res: SafeResponse): void => {
  const event = req.body.event;
  if (typeof event !== 'string') {
    res.status(400).send("missing 'event' parameter");
    return;
  }

  const sport = req.body.sport;
  if (typeof sport !== 'string') {
    res.status(400).send("missing 'sport' parameter");
    return;
  }

  const description = req.body.description;
  if (typeof description !== 'string') {
    res.status(400).send("missing 'description' parameter");
    return;
  }

  const day = req.body.day;
  if (typeof day !== "number") {
    res.status(400).send(`'day' is not a number: ${day}`);
    return;
  } else if (isNaN(day) || day < 1 || day > 31 || Math.round(day) !== day) {
    res.status(400).send(`'day' is not a positive integer between 1-31: ${day}`);
    return;
  }

  const venue = req.body.venue;
  if (typeof venue !== 'string') {
    res.status(400).send("missing 'venue' parameter");
    return;
  }

  const maxTickets = req.body.maxTickets;
  if (typeof maxTickets !== "number") {
    res.status(400).send(`'maxTickets' is not a number: ${maxTickets}`);
    return;
  } else if (isNaN(maxTickets) || maxTickets < 1 || Math.round(maxTickets) !== maxTickets) {
    res.status(400).send(`'maxTickets' is not a positive integer: ${maxTickets}`);
    return;
  }

  const olympicEvent: Event = {
    event: event,
    sport: sport,
    description: description,
    day: day,
    venue: venue,
    maxTickets: maxTickets,
    ticketsLeft: maxTickets
  };
  events.set(`${event},${sport}`, olympicEvent); // add this to the map of events
  res.send({event: olympicEvent});  // send the event we made
}

// Helper to return the (first) value of the parameter if any was given.
// (This is mildly annoying because the client can also give mutiple values,
// in which case, express puts them into an array.)
const first = (param: unknown): string|undefined => {
  if (Array.isArray(param)) {
    return first(param[0]);
  } else if (typeof param === 'string') {
    return param;
  } else {
    return undefined;
  }
};
