import * as assert from 'assert';
import * as httpMocks from 'node-mocks-http';
import { listEvents, eventsMap, addEvent, resetForTesting, Event, getTickets } from './routes';

describe('routes', function() {

  beforeEach(function() {
    resetForTesting(); // Reset state before each test
  });

  it('add', function() {
    // 1. Missing event
    const req1 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: {}
    });
    const res1 = httpMocks.createResponse();
    addEvent(req1, res1);
    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(), "missing 'event' parameter");

    // 1.a Missing event - non string
    const req1a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: {event: 0}
    });
    const res1a = httpMocks.createResponse();
    addEvent(req1a, res1a);
    assert.strictEqual(res1a._getStatusCode(), 400);
    assert.deepStrictEqual(res1a._getData(), "missing 'event' parameter");

    // 2. Missing sport
    const req2 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a" }
    });
    const res2 = httpMocks.createResponse();
    addEvent(req2, res2);
    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(), "missing 'sport' parameter");

    // 2.a Missing sport - non string
    const req2a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: 0 }
    });
    const res2a = httpMocks.createResponse();
    addEvent(req2a, res2a);
    assert.strictEqual(res2a._getStatusCode(), 400);
    assert.deepStrictEqual(res2a._getData(), "missing 'sport' parameter");

    // 3. Missing description
    const req3 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1" }
    });
    const res3 = httpMocks.createResponse();
    addEvent(req3, res3);
    assert.strictEqual(res3._getStatusCode(), 400);
    assert.deepStrictEqual(res3._getData(), "missing 'description' parameter");

    // 3.a Missing description - non string
    const req3a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: 0 }
    });
    const res3a = httpMocks.createResponse();
    addEvent(req3a, res3a);
    assert.strictEqual(res3a._getStatusCode(), 400);
    assert.deepStrictEqual(res3a._getData(), "missing 'description' parameter");

    // 4. Missing day
    const req4 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc"}
    });
    const res4 = httpMocks.createResponse();
    addEvent(req4, res4);
    assert.strictEqual(res4._getStatusCode(), 400);
    assert.deepStrictEqual(res4._getData(), "'day' is not a number: undefined");

    // 4.a invalid day - NaN
    const req4a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: NaN}
    });
    const res4a = httpMocks.createResponse();
    addEvent(req4a, res4a);
    assert.strictEqual(res4a._getStatusCode(), 400);
    assert.deepStrictEqual(res4a._getData(), "'day' is not a positive integer between 1-31: NaN");

    // 4.b invalid day - < 1
    const req4b = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 0}
    });
    const res4b = httpMocks.createResponse();
    addEvent(req4b, res4b);
    assert.strictEqual(res4b._getStatusCode(), 400);
    assert.deepStrictEqual(res4b._getData(), "'day' is not a positive integer between 1-31: 0");

    // 4.c invalid day - > 31
    const req4c = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 32}
    });
    const res4c = httpMocks.createResponse();
    addEvent(req4c, res4c);
    assert.strictEqual(res4c._getStatusCode(), 400);
    assert.deepStrictEqual(res4c._getData(), "'day' is not a positive integer between 1-31: 32");

    // 4.d invalid day - integer
    const req4d = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 13.5}
    });
    const res4d = httpMocks.createResponse();
    addEvent(req4d, res4d);
    assert.strictEqual(res4d._getStatusCode(), 400);
    assert.deepStrictEqual(res4d._getData(), "'day' is not a positive integer between 1-31: 13.5");

    // 5. Missing venue
    const req5 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 5}
    });
    const res5 = httpMocks.createResponse();
    addEvent(req5, res5);
    assert.strictEqual(res5._getStatusCode(), 400);
    assert.deepStrictEqual(res5._getData(), "missing 'venue' parameter");

    // 5.a Missing venue - non string
    const req5a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 5, venue: 1}
    });
    const res5a = httpMocks.createResponse();
    addEvent(req5a, res5a);
    assert.strictEqual(res5a._getStatusCode(), 400);
    assert.deepStrictEqual(res5a._getData(), "missing 'venue' parameter");

    // 6. Missing maxTickets
    const req6 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 5, venue: "venue"}
    });
    const res6 = httpMocks.createResponse();
    addEvent(req6, res6);
    assert.strictEqual(res6._getStatusCode(), 400);
    assert.deepStrictEqual(res6._getData(), "'maxTickets' is not a number: undefined");

    // 6.a Invalid maxTickets - NaN
    const req6a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 5, venue: "venue", maxTickets: NaN}
    });
    const res6a = httpMocks.createResponse();
    addEvent(req6a, res6a);
    assert.strictEqual(res6a._getStatusCode(), 400);
    assert.deepStrictEqual(res6a._getData(), "'maxTickets' is not a positive integer: NaN");

    // 6.b Invalid maxTickets - < 1
    const req6b = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 5, venue: "venue", maxTickets: 0}
    });
    const res6b = httpMocks.createResponse();
    addEvent(req6b, res6b);
    assert.strictEqual(res6b._getStatusCode(), 400);
    assert.deepStrictEqual(res6b._getData(), "'maxTickets' is not a positive integer: 0");

    // 6.c Invalid maxTickets - integer
    const req6c = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "a", sport: "a1", description: "desc", day: 5, venue: "venue", maxTickets: 2.5}
    });
    const res6c = httpMocks.createResponse();
    addEvent(req6c, res6c);
    assert.strictEqual(res6c._getStatusCode(), 400);
    assert.deepStrictEqual(res6c._getData(), "'maxTickets' is not a positive integer: 2.5");

    // 7. Successfully adding a valid event
    const req7 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "validEvent", sport: "validSport", description: "validDesc", day: 15, venue: "validVenue", maxTickets: 100 }
    });
    const res7 = httpMocks.createResponse();
    addEvent(req7, res7);

    const validEvent: Event = {
      event: "validEvent",
      sport: "validSport",
      description: "validDesc",
      day: 15,
      venue: "validVenue",
      maxTickets: 100,
      ticketsLeft: 100
    };

    assert.deepStrictEqual(res7._getStatusCode(), 200);
    assert.deepStrictEqual(res7._getData().event, validEvent);
  });

  it('list', function() {
    // empty list
    const req1 = httpMocks.createRequest(
      {method: 'GET', url: '/api/list', query: {}});
    const res1 = httpMocks.createResponse();
    listEvents(req1, res1);
    assert.strictEqual(res1._getStatusCode(), 200);
    assert.deepStrictEqual(res1._getData(), {events: [], top3: []});

    // Add Events
    const reqA1 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "validEvent", sport: "validSport", description: "validDesc", day: 15, venue: "validVenue", maxTickets: 100 }
    });
    const resA1 = httpMocks.createResponse();
    addEvent(reqA1, resA1);
    assert.deepStrictEqual(resA1._getStatusCode(), 200);
    assert.deepStrictEqual(resA1._getData().event.event, "validEvent");
    assert.deepStrictEqual(resA1._getData().event.day, 15);


    const reqA2 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "validEvent2", sport: "validSport2", description: "validDesc2", day: 1, venue: "validVenue2", maxTickets: 300 }
    });
    const resA2 = httpMocks.createResponse();
    addEvent(reqA2, resA2);
    assert.deepStrictEqual(resA2._getStatusCode(), 200);
    assert.deepStrictEqual(resA2._getData().event.event, "validEvent2");
    assert.deepStrictEqual(resA2._getData().event.day, 1);


    const reqA3 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "validEvent3", sport: "validSport3", description: "validDesc3", day: 31, venue: "validVenue3", maxTickets: 10 }
    });
    const resA3 = httpMocks.createResponse();
    addEvent(reqA3, resA3);
    assert.deepStrictEqual(resA3._getStatusCode(), 200);
    assert.deepStrictEqual(resA3._getData().event.event, "validEvent3");
    assert.deepStrictEqual(resA3._getData().event.day, 31);


    // Correct order of chronological events
    const req2 = httpMocks.createRequest(
      {method: 'GET', url: '/api/list', query: {}});
    const res2 = httpMocks.createResponse();
    listEvents(req2, res2);
    assert.strictEqual(res2._getStatusCode(), 200);
    assert.deepStrictEqual(res2._getData().events[0].event, "validEvent2");
    assert.deepStrictEqual(res2._getData().events[1].event, "validEvent");
    assert.deepStrictEqual(res2._getData().events[2].event, "validEvent3");
    assert.deepStrictEqual(res2._getData().events.length, 3);

    // Buy some tickets
    const reqG1 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name1", ticketsBought: 10, sport: "validSport", event: "validEvent"}
    });
    const resG1 = httpMocks.createResponse();
    getTickets(reqG1, resG1);
    assert.deepStrictEqual(resG1._getStatusCode(), 200);
    assert.deepStrictEqual(resG1._getData().ticketsLeft, 90);

    const reqG2 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name2", ticketsBought: 200, sport: "validSport2", event: "validEvent2"}
    });
    const resG2 = httpMocks.createResponse();
    getTickets(reqG2, resG2);
    assert.deepStrictEqual(resG2._getStatusCode(), 200);
    assert.deepStrictEqual(resG2._getData().ticketsLeft, 100);

    // Correct order of tickets sold
    const req3 = httpMocks.createRequest(
      {method: 'GET', url: '/api/list', query: {}});
    const res3 = httpMocks.createResponse();
    listEvents(req3, res3);
    assert.strictEqual(res3._getStatusCode(), 200);
    assert.deepStrictEqual(res3._getData().top3[0].event, "validEvent2");
    assert.deepStrictEqual(res3._getData().top3[1].event, "validEvent");
    assert.deepStrictEqual(res3._getData().top3[2].event, "validEvent3");
    assert.deepStrictEqual(res3._getData().top3.length, 3);
  });

  it('get', function() {
    // Event does not exist on empty map
    const req1 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name1", ticketsBought: 12, sport: "validSport", event: "validEvent"}
    });
    const res1 = httpMocks.createResponse();
    getTickets(req1, res1);
    assert.deepStrictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(), "the given event key does not exist: [validEvent, validSport]");


    //Add Events
    const reqA1 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "validEvent", sport: "validSport", description: "validDesc", day: 15, venue: "validVenue", maxTickets: 100 }
    });
    const resA1 = httpMocks.createResponse();
    addEvent(reqA1, resA1);
    assert.deepStrictEqual(resA1._getStatusCode(), 200);
    assert.deepStrictEqual(resA1._getData().event.event, "validEvent");
    assert.deepStrictEqual(resA1._getData().event.day, 15);


    const reqA2 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "validEvent2", sport: "validSport2", description: "validDesc2", day: 1, venue: "validVenue2", maxTickets: 300 }
    });
    const resA2 = httpMocks.createResponse();
    addEvent(reqA2, resA2);
    assert.deepStrictEqual(resA2._getStatusCode(), 200);
    assert.deepStrictEqual(resA2._getData().event.event, "validEvent2");
    assert.deepStrictEqual(resA2._getData().event.day, 1);


    const reqA3 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "validEvent3", sport: "validSport3", description: "validDesc3", day: 31, venue: "validVenue3", maxTickets: 10 }
    });
    const resA3 = httpMocks.createResponse();
    addEvent(reqA3, resA3);
    assert.deepStrictEqual(resA3._getStatusCode(), 200);
    assert.deepStrictEqual(resA3._getData().event.event, "validEvent3");
    assert.deepStrictEqual(resA3._getData().event.day, 31);

    // 2. Missing name
    const req2 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {}
    });
    const res2 = httpMocks.createResponse();
    getTickets(req2, res2);
    assert.deepStrictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(), "missing 'name' parameter");

    // 2.a Missing name non string
    const req2a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {name: 0}
    });
    const res2a = httpMocks.createResponse();
    getTickets(req2a, res2a);
    assert.deepStrictEqual(res2a._getStatusCode(), 400);
    assert.deepStrictEqual(res2a._getData(), "missing 'name' parameter");

    // 3. Missing ticketsBought
    const req3 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {name: "name1"}
    });
    const res3 = httpMocks.createResponse();
    getTickets(req3, res3);
    assert.deepStrictEqual(res3._getStatusCode(), 400);
    assert.deepStrictEqual(res3._getData(), "'ticketsBought' is not a number: undefined");

    // 3.a Missing ticketsBought non number
    const req3a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {name: "name1", ticketsBought: "twelve"}
    });
    const res3a = httpMocks.createResponse();
    getTickets(req3a, res3a);
    assert.deepStrictEqual(res3a._getStatusCode(), 400);
    assert.deepStrictEqual(res3a._getData(), "'ticketsBought' is not a number: twelve");

    // 3.b invalid ticketsBought - < 1
    const req3b = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {name: "name1", ticketsBought: 0}
    });
    const res3b = httpMocks.createResponse();
    getTickets(req3b, res3b);
    assert.deepStrictEqual(res3b._getStatusCode(), 400);
    assert.deepStrictEqual(res3b._getData(), "'ticketsBought' is not a positive integer: 0");

    // 3.c invalid ticketsBought - non integer
    const req3c = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {name: "name1", ticketsBought: 13.44}
    });
    const res3c = httpMocks.createResponse();
    getTickets(req3c, res3c);
    assert.deepStrictEqual(res3c._getStatusCode(), 400);
    assert.deepStrictEqual(res3c._getData(), "'ticketsBought' is not a positive integer: 13.44");

    // 3.d invalid ticketsBought - NaN
    const req3d = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {name: "name1", ticketsBought: NaN}
    });
    const res3d = httpMocks.createResponse();
    getTickets(req3d, res3d);
    assert.deepStrictEqual(res3d._getStatusCode(), 400);
    assert.deepStrictEqual(res3d._getData(), "'ticketsBought' is not a positive integer: NaN");

    // 4. Missing sport
    const req4 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {name: "name1", ticketsBought: 12}
    });
    const res4 = httpMocks.createResponse();
    getTickets(req4, res4);
    assert.deepStrictEqual(res4._getStatusCode(), 400);
    assert.deepStrictEqual(res4._getData(), "missing 'sport' parameter");

    // 4.a Missing sport - non string
    const req4a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: {name: "name1", ticketsBought: 12, sport: 0}
    });
    const res4a = httpMocks.createResponse();
    getTickets(req4a, res4a);
    assert.deepStrictEqual(res4a._getStatusCode(), 400);
    assert.deepStrictEqual(res4a._getData(), "missing 'sport' parameter");

    // 5. Missing event
    const req5 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name1", ticketsBought: 12, sport: "validSport" }
    });
    const res5 = httpMocks.createResponse();
    getTickets(req5, res5);
    assert.deepStrictEqual(res5._getStatusCode(), 400);
    assert.deepStrictEqual(res5._getData(), "missing 'event' parameter");

    // 5.a Missing event - non string
    const req5a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name1", ticketsBought: 12, sport: "validSport", event: 0 }
    });
    const res5a = httpMocks.createResponse();
    getTickets(req5a, res5a);
    assert.deepStrictEqual(res5a._getStatusCode(), 400);
    assert.deepStrictEqual(res5a._getData(), "missing 'event' parameter");

    // 5.b non existent event key
    const req5b = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name1", ticketsBought: 12, sport: "validSport", event: "invalid" }
    });
    const res5b = httpMocks.createResponse();
    getTickets(req5b, res5b);
    assert.deepStrictEqual(res5b._getStatusCode(), 400);
    assert.deepStrictEqual(res5b._getData(), "the given event key does not exist: [invalid, validSport]");

    // 5.c event doesnt match sport
    const req5c = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name1", ticketsBought: 12, sport: "validSport3", event: "validEvent" }
    });
    const res5c = httpMocks.createResponse();
    getTickets(req5c, res5c);
    assert.deepStrictEqual(res5c._getStatusCode(), 400);
    assert.deepStrictEqual(res5c._getData(), "the given event key does not exist: [validEvent, validSport3]");

    // success on validEvent
    const req6 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name1", ticketsBought: 10, sport: "validSport", event: "validEvent"}
    });
    const res6 = httpMocks.createResponse();
    getTickets(req6, res6);
    assert.deepStrictEqual(res6._getStatusCode(), 200);
    assert.deepStrictEqual(res6._getData().ticketsLeft, 90);

    // 6.a tickets bought is greater than tickets left
    const req6a = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name1", ticketsBought: 91, sport: "validSport", event: "validEvent"}
    });
    const res6a = httpMocks.createResponse();
    getTickets(req6a, res6a);
    assert.deepStrictEqual(res6a._getStatusCode(), 400);
    assert.deepStrictEqual(res6a._getData(), "'ticketsBought' is greater than tickets left: 91 > 90");

    // success on validEvent3
    const req7 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/get',
      body: { name: "name3", ticketsBought: 10, sport: "validSport3", event: "validEvent3"}
    });
    const res7 = httpMocks.createResponse();
    getTickets(req7, res7);
    assert.deepStrictEqual(res7._getStatusCode(), 200);
    assert.deepStrictEqual(res7._getData().ticketsLeft, 0);
  });

  it('map', function() {
    // Empty Map
    const req1 = httpMocks.createRequest(
      {method: 'GET', url: '/api/map', query: {}});
    const res1 = httpMocks.createResponse();
    eventsMap(req1, res1);
    assert.strictEqual(res1._getStatusCode(), 200);
    assert.deepStrictEqual(res1._getData(), {map: []});

    // Add Event
    const reqA1 = httpMocks.createRequest({
      method: 'POST',
      url: '/api/add',
      body: { event: "validEvent", sport: "validSport", description: "validDesc", day: 15, venue: "validVenue", maxTickets: 100 }
    });
    const resA1 = httpMocks.createResponse();
    addEvent(reqA1, resA1);
    assert.deepStrictEqual(resA1._getStatusCode(), 200);
    assert.deepStrictEqual(resA1._getData().event.event, "validEvent");

    // 1 item in Map

    const req2 = httpMocks.createRequest(
      {method: 'GET', url: '/api/map', query: {}});
    const res2 = httpMocks.createResponse();
    eventsMap(req2, res2);
    const expectedArr = [["validEvent,validSport", {event: "validEvent", sport: "validSport", description: "validDesc", day: 15, venue: "validVenue", maxTickets: 100, ticketsLeft: 100}]];

    assert.strictEqual(res2._getStatusCode(), 200);
    assert.deepStrictEqual(res2._getData().map.length, 1);
    assert.deepStrictEqual(res2._getData().map, expectedArr);
  });

});
