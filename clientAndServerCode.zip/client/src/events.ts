import { isRecord } from "./record";

// Description of an individual event
// Restrictions:
// 1 <= day <= 31
// maxTickets > 0
// ticketsLeft >= 0
// all numerical values are integers
export type Event = {
  event: string,
  sport: string,
  description: string,
  day: number,
  venue: string,
  maxTickets: number,
  ticketsLeft: number
};

/**
 * Parses unknown data into Event. Will log an error and return undefined
 * if it is not a valid Event.
 * @param val unknown data to parse into Event
 * @returns Event if val is a valid Event and undefined otherwise
 */
export const parseEvent = (val: unknown): undefined | Event => {
  if (!isRecord(val)) {
    console.error("not an event", val);
    return undefined;
  }

  if (typeof val.event !== "string") {
    console.error("not an event: missing 'event'", val);
    return undefined;
  }

  if (typeof val.sport !== "string") {
    console.error("not an event: missing 'sport'", val);
    return undefined;
  }

  if (typeof val.description !== "string") {
    console.error("not an event: missing 'description'", val);
    return undefined;
  }
  if (typeof val.day !== "number" ||
      val.day < 1 || val.day >= 31 ||
      isNaN(val.day) || Math.round(val.day) !== val.day) {
    console.error("not an event: missing or invalid 'day'", val);
    return undefined;
  }
  if (typeof val.venue !== "string") {
    console.error("not an event: missing 'venue'", val);
    return undefined;
  }
  if (typeof val.maxTickets !== "number" || val.maxTickets < 1 ||
      isNaN(val.maxTickets) || Math.round(val.maxTickets) !== val.maxTickets) {
    console.error("not an event: missing or invalid 'maxTickets'", val);
    return undefined;
  }
  if (typeof val.ticketsLeft !== "number" || val.ticketsLeft < 0 ||
    isNaN(val.ticketsLeft) || Math.round(val.ticketsLeft) !== val.ticketsLeft) {
    console.error("not an event: missing or invalid 'ticketsLeft'", val);
    return undefined;
  }

  return {
    event: val.event,
    sport: val.sport,
    description: val.description,
    day: val.day,
    venue: val.venue,
    maxTickets: val.maxTickets,
    ticketsLeft: val.ticketsLeft
  };
}