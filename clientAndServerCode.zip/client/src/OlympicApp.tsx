import React, { Component } from "react";
import { EventList } from "./EventList";
import { GetEvent } from "./GetEventTicket";
import { AddEvent } from "./AddEvent";
import './olympics.css';

// Indicates what page to show
type Page = "list" | "add" | "get";

type OlympicAppState = {
  page: Page
};

// Whether to show debugging information in the console.
const DEBUG: boolean = true;

/** Displays the UI of the Olympic rsvp application. */
export class OlympicApp extends Component<{}, OlympicAppState> {

  constructor(props: {}) {
    super(props);

    this.state = {page: "list"};
  }

  render = (): JSX.Element => {
    if (this.state.page === "list") {
      if (DEBUG) console.debug("rendering list page");
      return <EventList onToAddClick={this.doToAddClick}
                        onToGetClick={this.doToGetClick}/>;
    } else if (this.state.page === "add") {
      if (DEBUG) console.debug("rendering add event page");
      return <AddEvent onBackClick={this.doBackClick}/>;

    } else {  // get
      if (DEBUG) console.debug("rendering get ticket page");
      return <GetEvent onBackClick={this.doBackClick}/>;
    }
  };

  doToAddClick = (): void => {
    if (DEBUG) console.debug("set state to add");
    this.setState({page: "add"});
  }

  doToGetClick = (): void => {
    if (DEBUG) console.debug("set state to get");
    this.setState({page: "get"});
  }

  doBackClick = (): void => {
    if (DEBUG) console.debug("set state to list");
    this.setState({page: "list"});
  };
}
