import React, { Component, MouseEvent } from 'react';
import { Event, parseEvent } from './events';
import { isRecord } from './record';
import './olympics.css';

type ListProps = {
  onToAddClick: () => void,
  onToGetClick: () => void
};

type ListState = {
  events: Event[] | undefined,
  top3Events: Event[] | undefined
};

// Whether to show debugging information in the console.
const DEBUG: boolean = true;

export class EventList extends Component<ListProps, ListState> {
  constructor(props: ListProps) {
    super(props);
    this.state = {events: undefined, top3Events: undefined};
  }

  componentDidMount = (): void => {
    this.doRefreshClick();
  };

  componentDidUpdate = (prevProps: ListProps): void => {
    if (prevProps !== this.props) {
      this.doRefreshClick();
    }
  };

  render = (): JSX.Element => {
    return (
      <div id="list-page">
        <div>
          <h2>Olmpic Event List</h2>
          {this.renderEvents()}
        </div>
        <div>
          <h2>Ranking</h2>
          {this.renderRanking()}
        </div>
        <div>
        <button type="button" onClick={this.doToAddClick}>Add Event</button>
        <button type="button" onClick={this.doToGetClick}>Get Tickets</button>
        <button type="button" onClick={this.doRefreshClick}>Refresh</button>
        {/* {this.renderRings()} */}
        </div>
      </div>);
  };

  renderEvents = (): JSX.Element => {
    if (DEBUG) {
      console.log(this.state.events);
    }
    if (this.state.events === undefined ||
        this.state.events.length === 0) {
      if (DEBUG) {
        console.log("this.state.events === undefined");
      }
      return <p>Currently no events available.</p>;
    } else {
      const events: JSX.Element[] = [];
      for (const event of this.state.events) {
        const eventText: string = event.event + " (" + event.sport + ") | ";
        const ticketText: string =
          (event.ticketsLeft === 0 ? "SOLD OUT" : event.ticketsLeft + " tickets");
        const finalText: string = eventText + ticketText + " | Aug. " +
                                  event.day + ", 2024";
        const key = event.event + "," + event.sport;
        events.push(
          <li key={key}>
            {finalText}
          </li>
        );
      }
      return <ul>{events}</ul>;
    }
  };

  renderRanking = (): JSX.Element => {
    if (this.state.top3Events === undefined) {
      return (
        <div>
          <p>Gold: N/A</p>
          <p>Silver: N/A</p>
          <p>Bronze: N/A</p>
        </div>
        );
    } else {
      const goldEvent = this.state.top3Events[0];
      const goldText: string = (goldEvent === undefined) ?
                               "N/A" : `${goldEvent.event} (${goldEvent.sport}) -
                               ${goldEvent.maxTickets - goldEvent.ticketsLeft} sold`;
      const silverEvent = this.state.top3Events[1];
      const silverText: string = (silverEvent === undefined) ?
                                "N/A" : `${silverEvent.event} (${silverEvent.sport}) -
                               ${silverEvent.maxTickets - silverEvent.ticketsLeft} sold`;
      const bronzeEvent = this.state.top3Events[2];
      const bronzeText: string = (bronzeEvent === undefined) ?
                                "N/A" : `${bronzeEvent.event} (${bronzeEvent.sport}) -
                               ${bronzeEvent.maxTickets - bronzeEvent.ticketsLeft} sold`;
      return (
        <div>
          <p>Gold: {goldText}</p>
          <p>Silver: {silverText}</p>
          <p>Bronze: {bronzeText}</p>
        </div>
      );
    }
  };

  doRefreshClick = (): void => {
    fetch("/api/list").then(this.doListResp)
      .catch(() => this.doListError("failed to connect to server"));
  };

  doListResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doListJson)
        .catch(() => this.doListError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doListError)
        .catch(() => this.doListError("400 response is not text"));
    } else {
      this.doListError(`bad status code from /api/list: ${resp.status}`);
    }
  };

  doListJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/list: not a record", data);
      return;
    }

    if (!Array.isArray(data.events) || !Array.isArray(data.top3)) {
      console.error("bad data from /api/list: events or top3 is not an array", data);
      return;
    }

    const events: Event[] = [];
    for (const val of data.events) {
      const event = parseEvent(val);
      if (event === undefined)
        return;
      events.push(event);
    }

    const top3: Event[] = [];
    for (const val of data.top3) {
      const event = parseEvent(val);
      if (event === undefined)
        return;
      top3.push(event);
    }
    this.setState({events: events, top3Events: top3});
  };

  doListError = (msg: string): void => {
    console.error(`Error fetching /api/list: ${msg}`);
  };

  doToAddClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    this.props.onToAddClick();
  };

  doToGetClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
    this.props.onToGetClick();
  }
}