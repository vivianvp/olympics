import React, { Component, ChangeEvent, MouseEvent } from 'react';
import { isRecord } from './record';
import { Event, parseEvent } from './events';


type GetProps = {
  onBackClick: () => void
};

type GetState = {
  events: Map<string, Event> | undefined,
  sportSelected: boolean,
  eventSelected: boolean,
  sport: string,
  event: string,
  name: string,
  ticketsBought: string,
  error: string
};

// Allow user to purchase a ticket to an olympic event
export class GetEvent extends Component<GetProps, GetState> {

  constructor(props: GetProps) {
    super(props);
    this.state = {
      events: undefined,
      sportSelected: false,
      eventSelected: false,
      sport: "",
      event: "",
      name: "",
      ticketsBought: "",
      error: ""
    };
  }

  componentDidMount = (): void => {
    this.doRefreshClick();
  };

  componentDidUpdate = (prevProps: GetProps): void => {
    if (prevProps !== this.props) {
      this.doRefreshClick();
    }
  };

  render = (): JSX.Element => {
    return (
      <div>
        <h2>Get Event Tickets</h2>
          {this.renderSports()}
          {this.renderEvents()}
          {this.renderPurchaseInfo()}
          <button type='button' onClick={this.doBackClick}>Back</button>
          {this.renderError()}
      </div>
    );
  };

  renderSports = (): JSX.Element => {
    if (this.state.events === undefined) {
      return <p>Currently no future events to purchase tickets for.</p>
    } else {
      const sportsOptions: JSX.Element[] = [];
      for (const event of this.state.events.values()) {
        const sport = event.sport;
        sportsOptions.push(<option value={sport}>{sport}</option>);
      }
      return (
        <div>
          <label htmlFor="sport">Sport:</label>
          <select name="sport" id="sport" onChange={this.doSportChange}>
            <option value="" disabled selected></option>
            {sportsOptions}
          </select>
        </div>
      );
    }
  };

  renderEvents = (): JSX.Element => {
    if (this.state.sportSelected && this.state.events !== undefined) {
      const eventOptions: JSX.Element[] = [];
      const eventsOfChosenSport = Array.from(this.state.events.values()).filter(event => event.sport === this.state.sport);
      for (const event of eventsOfChosenSport) {
        const eventOption = event.event;
        eventOptions.push(<option value={eventOption}>{eventOption}</option>);
      }
      return (
        <div>
          <label htmlFor="event">Event:</label>
          <select name="event" id="event" onChange={this.doEventChange}>
            <option value="" disabled selected></option>
            {eventOptions}
          </select>
        </div>
      );
    } else { // sports not selected
      return <div></div>;
    }
  };

  renderPurchaseInfo = (): JSX.Element | undefined => {
    if (this.state.events !== undefined &&
        this.state.sportSelected === true &&
        this.state.eventSelected === true ) {
      const chosenEvent = this.state.events.get(`${this.state.event},${this.state.sport}`);
      if (chosenEvent) {
        const description = chosenEvent.description;
        const day = chosenEvent.day;
        const venue = chosenEvent.venue;
        const ticketsLeft = chosenEvent.ticketsLeft;
        const maxTickets = chosenEvent.maxTickets;
        return (
          <div>
            <p>Description: {description}</p>
            <p>Date: Aug. {day}, 2024</p>
            <p>Venue: {venue}</p>
            <p>Tickets Available: {ticketsLeft}/{maxTickets}</p>
            <label htmlFor="name">Name:</label>
            <input type="text" name="name" id="name" onChange={this.doNameChange}></input>
            <label htmlFor="ticketsBought">Num. Tickets:</label>
            <input type="text" name="ticketsBought" id="ticketsBought" min="1" step="1" onChange={this.doNumTicketsChange}></input>
            <button type='button' onClick={this.doGetTicketClick}>Get Tickets</button>
          </div>
        );
      } else {
        this.setState({error: `The chosen event does not exist: ${this.state.event}`});
        return;
      }
    } else {
      return <div></div>;
    }
  };

  doGetTicketClick = (_: MouseEvent<HTMLButtonElement>): void => {
    if (this.state.name.trim().length === 0 ||
        this.state.sport.trim().length === 0 ||
        this.state.event.trim().length === 0 ||
        this.state.ticketsBought.trim().length === 0) {
      this.setState({error: "a required field is missing."});
      return;
    }

    if (this.state.events === undefined) {
      this.setState({error: "events map is undefined"});
      return;
    }

    const ticketsBought = parseFloat(this.state.ticketsBought);
    if (isNaN(ticketsBought) || ticketsBought < 1 || Math.floor(ticketsBought) !== ticketsBought) {
      this.setState({error: "Num. Tickets is not a positive integer"});
      return;
    }

    if (!this.state.events.has(`${this.state.event},${this.state.sport}`)) {
      this.setState({error: `chosen event does not exist: ${this.state}`});
      return;
    }

    const chosenEvent = this.state.events.get(`${this.state.event},${this.state.sport}`);
    if (chosenEvent !== undefined) {
      if (ticketsBought > chosenEvent.ticketsLeft) {
        this.setState({error: `Num. Tickets cannot be greater than tickets available: ${chosenEvent.ticketsLeft}`});
        return;
      }
    }

    const args = {
      name: this.state.name,
      ticketsBought: ticketsBought,
      sport: this.state.sport,
      event: this.state.event
    };
    fetch("/api/get", {
      method: "POST", body: JSON.stringify(args),
      headers: {"Content-Type": "application/json"} })
    .then(this.doGetResp)
    .catch(() => this.doGetError("failed to connect to server"));
  };

  doGetResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doGetJson)
          .catch(() => this.doGetError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doGetError)
          .catch(() => this.doGetError("400 response is not text"));
    } else {
      this.doGetError(`bad status code from /api/add: ${resp.status}`);
    }
  };

  doGetJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/add: not a record", data);
      return;
    }

    this.props.onBackClick();  // show the updated list
  };

  doGetError = (msg: string): void => {
    this.setState({error: msg})
  };

  doNameChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({name: evt.target.value, error: ""});
  };

  doNumTicketsChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ticketsBought: evt.target.value, error: ""});
  };

  doSportChange = (evt: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({sportSelected: true, sport: evt.target.value});
  };

  doEventChange = (evt: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({eventSelected: true, event: evt.target.value});
  };

  doRefreshClick = (): void => {
    fetch("/api/map").then(this.doMapResp)
      .catch(() => this.doMapError("failed to connect to server"));
  };

  doMapResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doMapJson)
        .catch(() => this.doMapError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doMapError)
        .catch(() => this.doMapError("400 response is not text"));
    } else {
      this.doMapError(`bad status code from /api/map: ${resp.status}`);
    }
  };

  doMapJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/map: not a record", data);
      return;
    }

    if (!Array.isArray(data.map)) {
      console.error("bad data from /api/map: 'map' is not an array", data);
      return;
    }

    const events: Map<string, Event> = new Map();
    for (const entry of data.map) {
      const event = parseEvent(entry[1]);
      if (event === undefined)
        return;
      events.set(entry[0], event);
    }

    this.setState({events: events});
  };

  doMapError = (msg: string): void => {
    console.error(`Error fetching /api/map: ${msg}`);
  };

  renderError = (): JSX.Element => {
    if (this.state.error.length === 0) {
      return <div></div>;
    } else {
      const style = {width: '300px', backgroundColor: 'rgb(246,194,192)',
          border: '1px solid rgb(137,66,61)', borderRadius: '5px', padding: '5px' };
      return (<div style={{marginTop: '15px'}}>
          <span style={style}><b>Error</b>: {this.state.error}</span>
        </div>);
    }
  };

  doBackClick = (_: MouseEvent<HTMLButtonElement>): void => {
    this.props.onBackClick();  // tell the parent this was clicked
  };
}