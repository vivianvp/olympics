import React, { Component, ChangeEvent, MouseEvent } from 'react';
import { isRecord } from './record';

type AddEventProps = {
  onBackClick: () => void
};

type AddEventState = {
  event: string,
  sport: string,
  description: string,
  day: string,
  venue: string,
  maxTickets: string,
  error: string
};

// Allows the user to create a new event
export class AddEvent extends Component<AddEventProps, AddEventState> {

  constructor(props: AddEventProps) {
    super(props);
    this.state = {
      event: "",
      sport: "",
      description: "",
      day: "1",
      venue: "",
      maxTickets: "",
      error:""
    };
  }

  render = (): JSX.Element => {
    return (
      <div>
        <h2>Add Event</h2>
        <div>
          <label htmlFor="event">Event:</label>
          <input id="event" type="text" value={this.state.event}
              onChange={this.doEventChange}></input>
        </div>
        <div>
          <label htmlFor="sport">Sport:</label>
          <input id="sport" type="text" value={this.state.sport}
              onChange={this.doSportChange}></input>
        </div>
        <div>
          <label htmlFor="description">Description:</label>
          <input id="description" type="text" value={this.state.description}
              onChange={this.doDescChange}></input>
        </div>
        <div>
          <label htmlFor="day">
            Date: August
            <input id="day" type="number" min="1" max="31" step="1" value={this.state.day}
              onChange={this.doDayChange}></input>
            , 2024
          </label>
        </div>
        <div>
          <label htmlFor="venue">Venue:</label>
          <input id="venue" type="text" value={this.state.venue}
              onChange={this.doVenueChange}></input>
        </div>
        <div>
          <label htmlFor="maxTickets">Max Tickets Available:</label>
          <input id="maxTickets" type="number" min="1" step="1" value={this.state.maxTickets}
              onChange={this.doMaxTicketsChange}></input>
        </div>
        <button type="button" onClick={this.doBackClick}>Back</button>
        <button type="button" onClick={this.doCreateClick}>Create</button>
        {this.renderError()}
      </div>
    );
  };

  renderError = (): JSX.Element => {
    if (this.state.error.length === 0) {
      return <div></div>;
    } else {
      const style = {width: '300px', backgroundColor: 'rgb(246,194,192)',
          border: '1px solid rgb(137,66,61)', borderRadius: '5px', padding: '5px' };
      return (<div style={{marginTop: '15px'}}>
          <span style={style}><b>Error</b>: {this.state.error}</span>
        </div>);
    }
  };

  doEventChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({event: evt.target.value, error: ""});
  };

  doSportChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({sport: evt.target.value, error: ""});
  };

  doDescChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({description: evt.target.value, error: ""});
  };

  doDayChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({day: evt.target.value, error: ""});
  };

  doVenueChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({venue: evt.target.value, error: ""});
  };

  doMaxTicketsChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({maxTickets: evt.target.value, error: ""});
  };

  doCreateClick = (_: MouseEvent<HTMLButtonElement>): void => {
    // Verify that the user entered all required information.
    if (this.state.event.trim().length === 0 ||
        this.state.sport.trim().length === 0 ||
        this.state.description.trim().length === 0 ||
        this.state.day.trim().length === 0 ||
        this.state.venue.trim().length === 0 ||
        this.state.maxTickets.trim().length === 0) {
      this.setState({error: "a required field is missing."});
      return;
    }

    // Verify that day is a valid number.
    const day = parseFloat(this.state.day);
    if (isNaN(day) || day < 1 || day > 31 || Math.floor(day) !== day) {
      this.setState({error: "Day is not a positive integer between 1 - 31"});
      return;
    }

    // Verify that maxTickets is a valid number.
    const maxTickets = parseFloat(this.state.maxTickets);
    if (isNaN(maxTickets) || maxTickets < 1 || Math.floor(maxTickets) !== maxTickets) {
      this.setState({error: "Max Tickets is not a positive integer"});
      return;
    }

    // Ask the app to add this event (adding it to the list).
    const args = {
      event: this.state.event,
      sport: this.state.sport,
      description: this.state.description,
      day: day,
      venue: this.state.venue,
      maxTickets: maxTickets
    };
    fetch("/api/add", {
        method: "POST", body: JSON.stringify(args),
        headers: {"Content-Type": "application/json"} })
      .then(this.doAddResp)
      .catch(() => this.doAddError("failed to connect to server"));
  };

  doAddResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doAddJson)
          .catch(() => this.doAddError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doAddError)
          .catch(() => this.doAddError("400 response is not text"));
    } else {
      this.doAddError(`bad status code from /api/add: ${resp.status}`);
    }
  };

  doAddJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/add: not a record", data);
      return;
    }

    this.props.onBackClick();  // show the updated list
  };

  doAddError = (msg: string): void => {
    this.setState({error: msg})
  };

  doBackClick = (_: MouseEvent<HTMLButtonElement>): void => {
    this.props.onBackClick();  // tell the parent this was clicked
  };
}